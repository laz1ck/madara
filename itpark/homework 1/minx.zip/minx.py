# 1chi vazifa
# otam = {
#     "ismi": "Mavlutdin",
#     "tug'ilgan yili": 1954,
#     "shahri": "Samarqand viloyati",
# }

# onam = {
#     "ismi": "barno",
#     "tug'ilgan yili": 1990,
#     "shahri": "xorazm viloyati",
# }

# ukam = {
#     "ismi": "nurbek",
#     "tug'ilgan yili": 2000,
#     "shahri": "xorazm viloyati",
# }

# print(f"otamning ismi {otam['ismi']}, {otam["tug'ilgan yili"]} yilda,{otam['shahri']} tug'ilgan ")
# print(f"onamning ismi {onam['ismi']}, {onam["tug'ilgan yili"]} yilda,{onam['shahri']} tug'ilgan ")
# print(f"ukamning ismi {ukam['ismi']}, {ukam["tug'ilgan yili"]} yilda,{ukam['shahri']} tug'ilgan ")








# 2vazifa
# sevimli_taomlar = {
#     "Ali": "osh",
#     "Vali": "manti",
#     "sali": "shashlik",

# }

# print(f"Alining sevimli taomi {sevimli_taomlar['Ali']}.")
# print(f"Valining sevimli taomi {sevimli_taomlar['Vali']}.")
# print(f"salining sevimli taomi {sevimli_taomlar['sali']}.")






# 3chi vazifa
# python_lugat = {
#     "integer": "Butun son ya'ni kasrsiz son Masalan, 5, -3, 42.",
#     "float": "Haqiqiy son ya'ni kasrli son Masalan, 3.14, -0.001, 2.0.",
#     "string": "Matn yoki son girizsa boladi. Masalan, 'hello', '123', 'Python'.",
#     "list": "Elementlar ro'yxati Masalan, [1, 2, 3], ['a', 'b', 'c'].",
#     "dictionary": "juftliklari to'plami. Masalan, {'ismi': 'aziz', 'yoshi': 25}.",
#     "if": "Shartli operator biror shart barilsa shu shartni bajaradi.",
#     "else": "if sharti bajarilmasa else amali bajarladi",
#     "for": "Takrorlanuvchi sikl biror ro'yxat yoki ketma-ketlikni bosqichma-bosqich o'rganish uchun ishlatiladi.",
# }

# for soz, izoh in python_lugat.items():
#     print(f"{soz}: {izoh}")







# 4chi vazifa
# tarjima = {
#     "salom": "hello",
#     "olma": "aplle",
#     "noutbook": "laptop",
#     "dost": "friend"
# }

# soz = input("tarjima qilmoqchi so'zi kiriting: ")


# if soz in tarjima:
#     print(f"Tarjima: {tarjima[soz]}")
# else:
#     print("Bunday soz mavjud emas")




